﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {



    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        string str = "server=Your Server Name; Initial Catalog=sameer; User ID=sa; Password=***"; 
        SqlConnection cn = new SqlConnection(str);
        SqlCommand cmd = new SqlCommand("SpMyProcedure", cn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@Action", "Insert");
        cmd.Parameters.AddWithValue("@Name", txtName.Text);
        cmd.Parameters.AddWithValue("@Age", txtAge.Text);
        cmd.Parameters.AddWithValue("@Country", txtCountry.Text);
        cn.Open();
        cmd.ExecuteNonQuery();
        cn.Close();
    }


    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        string str = "server=Your Server Name; Initial Catalog=sameer; User ID=sa; Password=***"; 
        SqlConnection cn = new SqlConnection(str);
        SqlCommand cmd = new SqlCommand("SpMyProcedure", cn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@Action", "Update");
        cmd.Parameters.AddWithValue("@Name", txtName.Text);
        cmd.Parameters.AddWithValue("@Age", txtAge.Text);
        cmd.Parameters.AddWithValue("@Country", txtCountry.Text);
        cmd.Parameters.AddWithValue("@Id", txtId.Text);
        cn.Open();
        cmd.ExecuteNonQuery();
        cn.Close();
    }


    protected void btnDelete_Click(object sender, EventArgs e)
    {
        string str = "server=Your Server Name; Initial Catalog=sameer; User ID=sa; Password=***"; 
        SqlConnection cn = new SqlConnection(str);
        SqlCommand cmd = new SqlCommand("SpMyProcedure", cn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@Action", "Delete");
        cmd.Parameters.AddWithValue("@Id", txtId.Text);
        cn.Open();
        cmd.ExecuteNonQuery();
        cn.Close();
    }  

}